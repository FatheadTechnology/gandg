<template>
  <div class="hello">
    <div class="btn primary-btn">
      FIND YOUR STYLE

    </div>
    <div class="btn secondary-btn">
      SEE ALL PATTERNS

    </div>

    <a href="#">some link</a>
  </div>
</template>

<script>
  export default {
    name: 'HelloWorld',
    data () {
      return {
        msg: 'Welcome to Your Vue.js App'
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
