<template>
  <div id="app">
    <!--TODO: make a left nav component-->
    <router-view/>
    <!--TODO: make a right nav component-->
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="scss">
  @import "./assets/styles/main.scss";
</style>
